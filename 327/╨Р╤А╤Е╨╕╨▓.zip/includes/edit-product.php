<?php
$id = $_GET['id'];
$product = $database->query("SELECT * FROM products WHERE id = $id")->fetch();
if(!$product){
    include('404.php');
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (empty($title) || empty($description) || empty($price)) {
        $errors[] = 'Заполните все поля';
    } elseif (strlen($title) < 4 || strlen($description) < 4) {
        $errors[] = 'Заполните не менее 4 символами';
    } elseif (!is_numeric($price)) {
        $errors[] = 'Цена должна быть числом';
    } elseif ($price < 100) {
        $errors[] = 'Цена должна быть не менее 100 рублей';
    }

    if(empty($errors)) {
        $stmt = $database->query("UPDATE products SET
                                        `title` = '$title', 
                                        `description` = '$description', 
                                        `price` = $price
                                        WHERE id = $id");
        header('Location: ./');
    }

}
?>

<form action="" method="post">
    <input type="text" name="title" placeholder="название" value="<?= $product['title'] ?>">
    <br>
    <textarea name="description" id="" cols="30" rows="10"
              placeholder="Описание"><?= $product['description'] ?></textarea>
    <br>
    <input type="text" name="price" placeholder="цена" value="<?= $product['price']?>">
    <br>
    <?php foreach ($errors as $error): ?>
        <div style="color: indianred"><?= $error ?></div>
    <?php endforeach; ?>
    <br>
    <input type="submit" placeholder="создать">

</form>
