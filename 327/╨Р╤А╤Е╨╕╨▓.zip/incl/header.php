<header>
    <a href="./">Главная</a>
    <a href="./?page=create-product">Создание товара</a>
</header>